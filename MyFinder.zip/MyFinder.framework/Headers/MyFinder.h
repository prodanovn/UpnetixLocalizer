//
//  MyFinder.h
//  MyFinder
//
//  Created by Nikolay Prodanov on 19.06.19.
//  Copyright © 2019 Nikolay Prodanov. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for MyFinder.
FOUNDATION_EXPORT double MyFinderVersionNumber;

//! Project version string for MyFinder.
FOUNDATION_EXPORT const unsigned char MyFinderVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MyFinder/PublicHeader.h>


