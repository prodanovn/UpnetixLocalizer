//
//  UpnetixLocalizer.h
//  UpnetixLocalizer
//
//  Created by Nikolay Prodanov on 28.06.19.
//  Copyright © 2019 Upnetix. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for UpnetixLocalizer.
FOUNDATION_EXPORT double UpnetixLocalizerVersionNumber;

//! Project version string for UpnetixLocalizer.
FOUNDATION_EXPORT const unsigned char UpnetixLocalizerVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <UpnetixLocalizer/PublicHeader.h>


